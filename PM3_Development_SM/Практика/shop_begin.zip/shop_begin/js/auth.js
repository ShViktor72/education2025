// TODO: переключение вкладок (Вход / Регистрация)

// TODO: регистрация нового пользователя (сохранять в localStorage)

// TODO: вход (проверять email + пароль в localStorage)

// TODO: при успешном входе сохранять currentUser в localStorage и перенаправлять на index.html
